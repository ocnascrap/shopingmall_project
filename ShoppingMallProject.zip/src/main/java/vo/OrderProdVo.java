package vo;

public class OrderProdVo {

	int o_idx;
	int p_idx;
	String m_id;
	String o_name;  
	int o_count;
	String o_color;
	String o_size;
	String o_date;

	
	public OrderProdVo() {
		// TODO Auto-generated constructor stub
	}
	

	public OrderProdVo(int o_idx, int p_idx, String m_id, String o_name, int o_count, String o_color, String o_size,
			String o_date) {
		super();
		this.o_idx = o_idx;
		this.p_idx = p_idx;
		this.m_id = m_id;
		this.o_name = o_name;
		this.o_count = o_count;
		this.o_color = o_color;
		this.o_size = o_size;
		this.o_date = o_date;
	}



	public String getO_name() {
		return o_name;
	}

	public void setO_name(String o_name) {
		this.o_name = o_name;
	}

	public String getO_date() {
		return o_date;
	}

	public void setO_date(String o_date) {
		this.o_date = o_date;
	}

	public int getO_idx() {
		return o_idx;
	}

	public void setO_idx(int o_idx) {
		this.o_idx = o_idx;
	}

	public String getO_color() {
		return o_color;
	}

	public void setO_color(String o_color) {
		this.o_color = o_color;
	}

	public int getO_count() {
		return o_count;
	}

	public void setO_count(int o_count) {
		this.o_count = o_count;
	}

	public String getO_size() {
		return o_size;
	}

	public void setO_size(String o_size) {
		this.o_size = o_size;
	}

	public int getP_idx() {
		return p_idx;
	}

	public void setP_idx(int p_idx) {
		this.p_idx = p_idx;
	}

	
}