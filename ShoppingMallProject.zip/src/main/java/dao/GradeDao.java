package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.GradeVo;
import vo.MemberVo;
import vo.ProductVo;

public class GradeDao {

	SqlSession sqlSession;

	public SqlSession getSqlSession() {
		return sqlSession;
	}

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	public List<GradeVo> selectList() {
		// TODO Auto-generated method stub
		return sqlSession.selectList("grade.grade_list");
	}

	public GradeVo selectOne(String m_id) {
		// TODO Auto-generated method stub
		GradeVo vo = sqlSession.selectOne("grade.grade_one", m_id);
		return vo;
	}
	
	public int insert(GradeVo vo) {
		
		int res = sqlSession.insert("grade.grade_insert", vo);
		
		return res;
	}

	
}
