package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.InStockVo;
import vo.StockVo;

public class StockDao {

	SqlSession sqlSession;

	public SqlSession getSqlSession() {
		return sqlSession;
	}

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	public StockVo selectOne(String p_name) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne("stock.stock_one", p_name);
	}

	public int insert(InStockVo vo) {
		// TODO Auto-generated method stub
		return sqlSession.insert("stock.stock_insert", vo);
	}

	public int update(StockVo remainVo) {
		// TODO Auto-generated method stub
		return sqlSession.update("stock.stock_update", remainVo);
	}

	public List<StockVo> selectList() {
		// TODO Auto-generated method stub
		return sqlSession.selectList("stock.stock_list");
	}
	
}
