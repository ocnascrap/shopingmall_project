package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.OutStockVo;
import vo.ProductVo;

public class OutStockDao {

	
	SqlSession sqlSession;

	public SqlSession getSqlSession() {
		return sqlSession;
	}

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	public int insert(OutStockVo vo) {
		// TODO Auto-generated method stub
		return sqlSession.insert("outstock.outstock_insert", vo);
	}

	public ProductVo selectOne(String p_name) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne("outstock.outstock_one", p_name);
	}

	public List<OutStockVo> selectList() {
		// TODO Auto-generated method stub
		return sqlSession.selectList("outstock.outstock_list");
	}
	
}
