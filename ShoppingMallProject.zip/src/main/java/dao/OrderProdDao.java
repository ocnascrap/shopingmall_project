package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.OrderProdVo;


public class OrderProdDao {

	SqlSession sqlSession;

	public SqlSession getSqlSession() {
		return sqlSession;
	}

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	public int insert(OrderProdVo vo) {
		// TODO Auto-generated method stub
		return sqlSession.insert("orderprod.orderprod_insert", vo);
	}

	public List<OrderProdVo> selectList() {
		// TODO Auto-generated method stub
		return sqlSession.selectList("orderprod.orderprod_list");
	}
	
}
