package vo;

public class GradeVo {

	
	String g_grade; 
 	int g_count; 
 	int g_price;
 	String g_recdate;
 	String g_joindate;
	
 	public GradeVo() {
		// TODO Auto-generated constructor stub
	}
	
 	String m_id;
	public GradeVo(String m_id, String g_grade, int g_count, int g_price, String g_recdate, String g_joindate) {
		super();
		this.m_id = m_id;
		this.g_grade = g_grade;
		this.g_count = g_count;
		this.g_price = g_price;
		this.g_recdate = g_recdate;
		this.g_joindate = g_joindate;
	}
	public String getG_grade() {
		return g_grade;
	}
	public void setG_grade(String g_grade) {
		this.g_grade = g_grade;
	}
	public int getG_count() {
		return g_count;
	}
	public void setG_count(int g_count) {
		this.g_count = g_count;
	}
	public int getG_price() {
		return g_price;
	}
	public void setG_price(int g_price) {
		this.g_price = g_price;
	}
	public String getG_recdate() {
		return g_recdate;
	}
	public void setG_recdate(String g_recdate) {
		this.g_recdate = g_recdate;
	}
	public String getG_joindate() {
		return g_joindate;
	}
	public void setG_joindate(String g_joindate) {
		this.g_joindate = g_joindate;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}

}
